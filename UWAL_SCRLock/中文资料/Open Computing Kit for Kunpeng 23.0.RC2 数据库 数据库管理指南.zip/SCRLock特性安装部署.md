# SCRLock特性安装部署<a name="ZH-CN_TOPIC_0000001721852965"></a>

-   **[环境要求](环境要求-1.md)**  

-   **[启用SCRLock特性](启用SCRLock特性.md)**  
启用SCRLock特性，需要通过修改配置文件，重启数据库使其生效。
-   **[关闭SCRLock特性](关闭SCRLock特性.md)**  
关闭SCRLock特性，需要重启数据库使配置生效。

