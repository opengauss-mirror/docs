# GUC参数说明<a name="ZH-CN_TOPIC_0000001619939278"></a>

-   **[UWAL的配置参数说明](UWAL的配置参数说明.md)**  

-   **[SCRLock的配置参数说明](SCRLock的配置参数说明.md)**  

