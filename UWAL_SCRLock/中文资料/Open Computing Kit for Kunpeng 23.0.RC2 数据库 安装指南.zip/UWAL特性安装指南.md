# UWAL特性安装指南<a name="ZH-CN_TOPIC_0000001673877862"></a>

-   **[介绍](介绍.md)**  
本章节主要介绍openGauss数据库UWAL（Unified Write-Ahead Log）特性的安装使用，指导用户顺利完成操作。本特性将数据库和自研公共组件UWAL相结合，以提高数据库的主备事务提交和流复制传输性能，从而加速WAL（Write-Ahead Log）的处理效率。
-   **[安装准备](安装准备.md)**  

-   **[安装卸载](安装卸载.md)**  

