# SCRLock特性<a name="ZH-CN_TOPIC_0000001673808978"></a>

在资源池化场景下使用SCRLock（Smart Cached Remote Lock）提供分布式锁能力，提高分布式锁性能。

