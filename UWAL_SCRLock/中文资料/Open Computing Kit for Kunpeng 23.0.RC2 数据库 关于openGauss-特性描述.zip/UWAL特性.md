# UWAL特性<a name="ZH-CN_TOPIC_0000001638970168"></a>

本特性将数据库和自研公共组件UWAL（Unified Write-Ahead Log）相结合，提高数据库的主备事务提交和流复制传输性能，实现数据库WAL（Write-Ahead Log）的性能加速效果。

