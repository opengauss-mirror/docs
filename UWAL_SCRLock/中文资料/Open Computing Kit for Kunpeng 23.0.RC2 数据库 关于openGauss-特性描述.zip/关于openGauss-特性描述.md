# 关于openGauss-特性描述<a name="ZH-CN_TOPIC_0000001638810908"></a>

-   **[特性描述](特性描述.md)**  

