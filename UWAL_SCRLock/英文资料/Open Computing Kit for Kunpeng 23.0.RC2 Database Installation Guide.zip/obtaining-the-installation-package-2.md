# Obtaining the Installation Package<a name="EN-US_TOPIC_0000001757750645"></a>

Obtain the UWAL installation package from the openGauss community.

