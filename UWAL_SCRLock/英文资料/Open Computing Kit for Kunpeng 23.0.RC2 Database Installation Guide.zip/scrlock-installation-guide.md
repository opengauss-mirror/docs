# SCRLock Installation Guide<a name="EN-US_TOPIC_0000001721917033"></a>

-   **[Introduction](introduction-0.md)**  
This chapter describes how to install and use the SCRLock feature of the openGauss database. When resource pooling is enabled, SCRLock can be used to provide the distributed lock capability, improving distributed lock performance.
-   **[Preparations](preparations-1.md)**  

-   **[Installation and Uninstallation](installation-and-uninstallation-4.md)**  

