# Preparations<a name="EN-US_TOPIC_0000001703641393"></a>

-   **[Obtaining the Installation Package](obtaining-the-installation-package.md)**  

-   **[Environment Requirements](environment-requirements.md)**  

