# Installation and Uninstallation<a name="EN-US_TOPIC_0000001718736133"></a>

-   **[One-Click Deployment of the UWAL Feature](one-click-deployment-of-the-uwal-feature.md)**  
UWAL allows one-click deployment through a simple deployment script.
-   **[Enabling the UWAL Feature](enabling-the-uwal-feature.md)**  
To enable the UWAL feature, modify the configuration file and restart the database for the modification to take effect.

