# Installation and Uninstallation<a name="EN-US_TOPIC_0000001721880305"></a>

-   **[One-Click Deployment of the SCRLock Feature](one-click-deployment-of-the-scrlock-feature.md)**  
SCRLock provides a simple deployment script. You can enter the installation path, installation user, and node information to perform one-click deployment.
-   **[Enabling the SCRLock Feature](enabling-the-scrlock-feature.md)**  
To enable the SCRLock feature, modify the configuration file and restart the database for the modification to take effect.
-   **[Disabling the SCRLock Feature](disabling-the-scrlock-feature.md)**  
To disable the SCRLock feature, modify the configuration file and restart the database for the configuration to take effect.

