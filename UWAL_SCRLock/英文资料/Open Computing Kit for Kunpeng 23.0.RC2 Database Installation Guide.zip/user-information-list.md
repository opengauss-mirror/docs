# User Information List<a name="EN-US_TOPIC_0000001772356493"></a>

**Table  1**  User information

<a name="table1143674515419"></a>
<table><thead align="left"><tr id="row5437204519419"><th class="cellrowborder" valign="top" width="19.27%" id="mcps1.2.5.1.1"><p id="p957781624414"><a name="p957781624414"></a><a name="p957781624414"></a>User</p>
</th>
<th class="cellrowborder" valign="top" width="44.800000000000004%" id="mcps1.2.5.1.2"><p id="p17577191654412"><a name="p17577191654412"></a><a name="p17577191654412"></a>Description</p>
</th>
<th class="cellrowborder" valign="top" width="12.97%" id="mcps1.2.5.1.3"><p id="p1257711166446"><a name="p1257711166446"></a><a name="p1257711166446"></a>Initial Password</p>
</th>
<th class="cellrowborder" valign="top" width="22.96%" id="mcps1.2.5.1.4"><p id="p357713169444"><a name="p357713169444"></a><a name="p357713169444"></a>Password Changing Method</p>
</th>
</tr>
</thead>
<tbody><tr id="row4437845947"><td class="cellrowborder" valign="top" width="19.27%" headers="mcps1.2.5.1.1 "><p id="p0509111719112"><a name="p0509111719112"></a><a name="p0509111719112"></a>omm</p>
</td>
<td class="cellrowborder" valign="top" width="44.800000000000004%" headers="mcps1.2.5.1.2 "><p id="p75092017131116"><a name="p75092017131116"></a><a name="p75092017131116"></a>User for managing the database, installing UWAL, and running UWAL and SCRLock.</p>
</td>
<td class="cellrowborder" valign="top" width="12.97%" headers="mcps1.2.5.1.3 "><p id="p2509131741110"><a name="p2509131741110"></a><a name="p2509131741110"></a>User-defined.</p>
</td>
<td class="cellrowborder" valign="top" width="22.96%" headers="mcps1.2.5.1.4 "><p id="p19509101714111"><a name="p19509101714111"></a><a name="p19509101714111"></a>Run the <strong id="b1512544317445"><a name="b1512544317445"></a><a name="b1512544317445"></a>passwd</strong> command to change the password.</p>
</td>
</tr>
<tr id="row17437145049"><td class="cellrowborder" valign="top" width="19.27%" headers="mcps1.2.5.1.1 "><p id="p18577516114419"><a name="p18577516114419"></a><a name="p18577516114419"></a>&lt;SCRLock-install-user&gt;</p>
</td>
<td class="cellrowborder" valign="top" width="44.800000000000004%" headers="mcps1.2.5.1.2 "><p id="p757720162443"><a name="p757720162443"></a><a name="p757720162443"></a>SCRLock installation user.</p>
</td>
<td class="cellrowborder" valign="top" width="12.97%" headers="mcps1.2.5.1.3 "><p id="p16577111619445"><a name="p16577111619445"></a><a name="p16577111619445"></a>User-defined.</p>
</td>
<td class="cellrowborder" valign="top" width="22.96%" headers="mcps1.2.5.1.4 "><p id="p25771616184420"><a name="p25771616184420"></a><a name="p25771616184420"></a>Run the <strong id="b2386194613442"><a name="b2386194613442"></a><a name="b2386194613442"></a>passwd</strong> command to change the password.</p>
</td>
</tr>
</tbody>
</table>

