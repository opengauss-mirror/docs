# Preparations<a name="EN-US_TOPIC_0000001709791682"></a>

-   **[Obtaining the Installation Package](obtaining-the-installation-package-2.md)**  

-   **[Environment Requirements](environment-requirements-3.md)**  

