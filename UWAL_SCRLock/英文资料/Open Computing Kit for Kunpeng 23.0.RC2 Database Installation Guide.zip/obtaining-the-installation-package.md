# Obtaining the Installation Package<a name="EN-US_TOPIC_0000001616261910"></a>

Obtain the UWAL installation package from the openGauss community.

