# Introduction<a name="EN-US_TOPIC_0000001721920141"></a>

This chapter describes how to install and use the SCRLock feature of the openGauss database. When resource pooling is enabled, SCRLock can be used to provide the distributed lock capability, improving distributed lock performance.

