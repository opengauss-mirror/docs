# UWAL Installation and Deployment<a name="EN-US_TOPIC_0000001741361420"></a>

-   **[Environment Requirements](environment-requirements.md)**  

-   **[Enabling the UWAL Feature](enabling-the-uwal-feature.md)**  
To enable the UWAL feature, modify the configuration file and restart the database for the modification to take effect.

