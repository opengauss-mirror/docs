# SCRLock Installation and Deployment<a name="EN-US_TOPIC_0000001721852965"></a>

-   **[Environment Requirements](environment-requirements-1.md)**  

-   **[Enabling the SCRLock Feature](enabling-the-scrlock-feature.md)**  
To enable the SCRLock feature, modify the configuration file and restart the database for the modification to take effect.
-   **[Disabling the SCRLock Feature](disabling-the-scrlock-feature.md)**  
To disable the SCRLock feature, modify the configuration file and restart the database for the configuration to take effect.

