# Version Description<a name="EN-US_TOPIC_0000001618495838"></a>

## What's New<a name="section10785138154515"></a>

[Enterprise-class feature](https://idp.huawei.com/idp-designer-war/design?op=edit&locate=newMode/EDIT/203370700883/EN-US_BOOKMAP_0000001673447609/EN-US_TOPIC_0000001687210125/2.1.1): The Unified Write-Ahead Log \(UWAL\) feature accelerates the Write-Ahead Log \(WAL\) performance of the database.

[High performance](https://idp.huawei.com/idp-designer-war/design?op=edit&locate=newMode/EDIT/203370700883/EN-US_BOOKMAP_0000001673447609/EN-US_TOPIC_0000001721808553/2.1.2): The SCRLock feature improves distributed lock performance.

