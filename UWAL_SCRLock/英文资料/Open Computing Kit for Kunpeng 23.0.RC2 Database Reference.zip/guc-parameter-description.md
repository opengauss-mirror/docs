# GUC Parameter Description<a name="EN-US_TOPIC_0000001619939278"></a>

-   **[UWAL Configuration Parameters](uwal-configuration-parameters.md)**  

-   **[SCRLock Configuration Parameters](scrlock-configuration-parameters.md)**  

