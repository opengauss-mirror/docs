# UWAL<a name="EN-US_TOPIC_0000001638970168"></a>

This feature combines the database and a Huawei-developed Unified Write-Ahead Log \(UWAL\) component to improve the performance of active/standby transaction submission as well as stream replication and transmission, accelerating the Write-Ahead Log \(WAL\) performance of the database.

