# About openGauss – Feature Description<a name="EN-US_TOPIC_0000001638810908"></a>

-   **[Feature Description](feature-description.md)**  

