# SCRLock<a name="EN-US_TOPIC_0000001673808978"></a>

When resource pooling is enabled, Smart Cached Remote Lock \(SCRLock\) can be used to provide the distributed lock capability, improving distributed lock performance.

