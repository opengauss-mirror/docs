# About openGauss – Enterprise-Class Enhanced Features<a name="EN-US_TOPIC_0000001687250905"></a>

-   **[Enterprise-Class Enhanced Features](enterprise-class-enhanced-features.md)**  

